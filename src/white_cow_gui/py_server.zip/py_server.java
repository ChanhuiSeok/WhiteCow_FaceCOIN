package white_cow_gui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class py_server extends Thread {

	public void run() {
		ServerSocket ssock = null;

		try {
			ssock = new ServerSocket(5080);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Socket csock = null;

		byte buffer[] = new byte[2048];

		File imgfile = new File("C:/JavaProgramming/source/white_cow_gui/test.jpg");

		String flen = String.valueOf(imgfile.length());

		// change "1234" to "0000001234", to make sure 10 size.

		String header = "0000000000".substring(0, 10 - flen.length()) + flen;

		try {
			csock = ssock.accept();
			
			FileInputStream fis = new FileInputStream(imgfile);

			OutputStream os = csock.getOutputStream();

			// send header

			// os.write(header.getBytes());

			// send body

			while (fis.available() > 0) {

				int readsz = fis.read(buffer);

				os.write(buffer, 0, readsz);

			}

			os.close();

			fis.close();
			
			ssock.close();
			/*while ((csock = ssock.accept()) != null) {

				FileInputStream fis = new FileInputStream(imgfile);

				OutputStream os = csock.getOutputStream();

				// send header

				// os.write(header.getBytes());

				// send body

				while (fis.available() > 0) {

					int readsz = fis.read(buffer);

					os.write(buffer, 0, readsz);

				}

				os.close();

				fis.close();
			}*/
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("�����ߴ٤�");
	}
} // run end
