package white_cow_gui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Loading extends Thread {

	ImageIcon transp = new ImageIcon("./picture/trans.png");
	
	public void run() {
		MyFrame.Loading.setBounds(455,100,790,610);
		
		MyFrame.Loading_message.setOpaque(false);
		MyFrame.Loading_message.setBounds(592,524,514,83);
		MyFrame.Loading_message.setFont(new Font("���� ������ 230", Font.PLAIN, 50));
		MyFrame.Loading_message.setForeground(new Color(255,255,255));
		MyFrame.Loading_message.setHorizontalAlignment(JLabel.CENTER);
		
		MyFrame.Loading_message.setText("�� �ν���");

		try {
			Loading.sleep(800);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyFrame.Loading_message.setText("�� �ν���.");
		
		try {
			Loading.sleep(800);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyFrame.Loading_message.setText("�� �ν���..");
		try {
			Loading.sleep(800);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyFrame.Loading_message.setText("�� �ν���...");
		try {
			Loading.sleep(800);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyFrame.Loading_message.setText("");
		MyFrame.Loading.setIcon(transp);
		
		MyFrame.resultback.setOpaque(true);
		MyFrame.resultback.setBounds(13,82,1236,776);
		MyFrame.resultback.setBackground(new Color(35,31,56));

		/*
		status.setText("");
		message.setText("");
		timer.setText("");
		time.flag2 = false;
		
		pro1.setText("");
		pro2.setText("");
		pro3.setText("");
		pro4.setText("");
		pro5.setText("");
		pro6.setText("");
		SUM.setText("");

		paybutton_basic.setIcon(transp);*/
		//63,60,82 - �⺻����
//////////////��� ȭ�� �󺧵� //////////////////////////////////////
    	//////////////��� ȭ�� �󺧵� //////////////////////////////////////
    	
		

    	MyFrame.back1.setBounds(88, 132, 1092, 80); 
    	MyFrame.back1.setOpaque(true);
    	MyFrame.back1.setFont(new Font("���� ������ 230", Font.PLAIN, 35));
    	MyFrame.back1.setBackground(new Color(6,99,76));
    	MyFrame.back1.setText( "�� - ���ν� �Ϸ�!");
    	MyFrame.back1.setHorizontalAlignment(JLabel.CENTER);
    	MyFrame.back1.setForeground(new Color(245,248,6));
    	MyFrame.checked.setBounds(112,139,61,61);
    	try {
			Loading.sleep(800);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  
    	MyFrame.back2.setBounds(88, 277, 1092, 80); 
    	MyFrame.back2.setOpaque(true);
    	MyFrame.back2.setFont(new Font("���� ������ 230", Font.PLAIN, 40));
    	MyFrame.back2.setBackground(new Color(63,60,82));
    	MyFrame.back2.setText("���� ��й�ȣ�� �Է��� �ֽʽÿ�.");
    	MyFrame.back2.setHorizontalAlignment(JLabel.CENTER);
    	MyFrame.back2.setForeground(new Color(255,255,255));
    	
    	MyFrame.back3.setBounds(88, 422, 1092, 80); 
    	MyFrame.back3.setOpaque(true);
    	MyFrame.back3.setFont(new Font("���� ������ 230", Font.PLAIN, 20));
    	MyFrame.back3.setBackground(new Color(63,60,82));
    	
    	//back4.setBounds(88, 567, 1092, 264); 
    	//back4.setOpaque(true);
    	//back4.setFont(new Font("���� ������ 230", Font.PLAIN, 20));
    	//back4.setBackground(new Color(63,60,82));

    	//////////////��� ȭ�� �󺧵� //////////////////////////////////////
    	//////////////��� ȭ�� �󺧵� //////////////////////////////////////
	}
	
}
